﻿namespace APICatalogo.Pagination;

public class CategoriasFiltroNome : QueryStringParameters
{
    public string? Nome { get; set; }
}
