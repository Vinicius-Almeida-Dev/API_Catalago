﻿namespace APICatalogo.Pagination;

public class CategoriasParameters: QueryStringParameters
{
}
