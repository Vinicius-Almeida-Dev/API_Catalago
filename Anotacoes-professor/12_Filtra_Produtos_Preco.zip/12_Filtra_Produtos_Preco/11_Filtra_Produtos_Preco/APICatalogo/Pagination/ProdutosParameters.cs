﻿namespace APICatalogo.Pagination;

public class ProdutosParameters : QueryStringParameters
{
   
}
